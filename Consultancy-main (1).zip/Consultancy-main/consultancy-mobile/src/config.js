// src/config.js
export const API_URL = "http://192.168.1.5:5000/api"; 
// ↑ replace 192.168.1.5 with YOUR PC IPv4 address
export const MOBILE_API_URL = "http://192.168.1.5:5000/api"; 